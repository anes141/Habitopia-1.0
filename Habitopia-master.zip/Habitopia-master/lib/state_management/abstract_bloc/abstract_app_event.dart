import 'package:flutter/cupertino.dart';

@immutable
abstract class HabitEvent {
  const HabitEvent();
}