import 'package:hive/hive.dart';

import 'models/habit.dart';

late Box<Habit> boxHabit;