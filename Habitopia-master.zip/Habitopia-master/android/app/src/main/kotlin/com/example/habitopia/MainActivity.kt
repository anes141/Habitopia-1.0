package com.example.habitopia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
